# instance/config.py
SECRET_KEY = "change-me-in-production"
SQLALCHEMY_DATABASE_URI = "sqlite:///mpf_scheduler.db"
SQLALCHEMY_TRACK_MODIFICATIONS = False
